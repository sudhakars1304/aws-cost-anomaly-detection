import json
import logging
import urllib3
import os

logging.basicConfig(level=logging.INFO)

def extract_flattened_anomalies(json_data):
    """Yields a dictionary per anomaly, with essential fields."""
    # Example assumes AWS CostAnomaly payload shape; adapt if needed.
    anomalies = json_data.get("anomalies", [json_data])
    for anomaly in anomalies:
        yield {
            "accountId": anomaly.get("accountId"),
            "accountName": anomaly.get("accountName"),
            "region": anomaly.get("rootCauses", {}).get("region"),
            "service": anomaly.get("rootCauses", {}).get("service"),
            "usageType": anomaly.get("rootCauses", {}).get("usageType"),
            "impact": anomaly.get("impact", {}),
            "anomalyDetailsLink": anomaly.get("anomalyDetailsLink"),
        }

def post_to_webhook(data):
    try:
        http = urllib3.PoolManager()
        webhook_url = os.environ['IntegrationURL']
        headers = {'Content-Type': 'application/json'}
        encoded_data = json.dumps(data).encode('utf-8')
        logging.info(f"Sending payload to Jira: {json.dumps(data)}")
        response = http.request("POST", webhook_url, headers=headers, body=encoded_data)
        logging.info(f'Data posted to webhook, status: {response.status}')
        print(f"POST request has been posted. Status: {response.status}")
        print(f"Response body: {response.data.decode()}")
        if response.status not in [200, 201, 204]:
            logging.error(f'Webhook responded with error status: {response.status}, body: {response.data.decode()}')
    except Exception as e:
        logging.error(f'Failed to post data to webhook: {e}')

def lambda_handler(event, context):
    logging.info(event)
    try:
        for record in event['Records']:
            sns_message = record['Sns']['Message']
            if isinstance(sns_message, str):
                sns_message = json.loads(sns_message)
            for anomaly_data in extract_flattened_anomalies(sns_message):
                post_to_webhook(anomaly_data)
    except Exception as e:
        logging.error(f'Error processing SNS message: {e}')
        raise e
